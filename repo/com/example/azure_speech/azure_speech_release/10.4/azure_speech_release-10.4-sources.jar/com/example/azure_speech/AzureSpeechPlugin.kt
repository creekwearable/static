package com.example.azure_speech

import android.os.Handler
import android.os.Looper
import com.microsoft.cognitiveservices.speech.PropertyId
import com.microsoft.cognitiveservices.speech.ResultReason
import com.microsoft.cognitiveservices.speech.SpeechConfig
import com.microsoft.cognitiveservices.speech.SpeechRecognitionResult
import com.microsoft.cognitiveservices.speech.SpeechRecognizer
import com.microsoft.cognitiveservices.speech.PhraseListGrammar
import com.microsoft.cognitiveservices.speech.audio.AudioConfig
import com.microsoft.cognitiveservices.speech.audio.PushAudioInputStream
import com.microsoft.cognitiveservices.speech.SessionEventArgs
import com.microsoft.cognitiveservices.speech.SpeechRecognitionEventArgs
import com.microsoft.cognitiveservices.speech.SpeechRecognitionCanceledEventArgs
import com.microsoft.cognitiveservices.speech.util.EventHandler
import com.microsoft.cognitiveservices.speech.translation.SpeechTranslationConfig
import com.microsoft.cognitiveservices.speech.translation.TranslationRecognizer
import com.microsoft.cognitiveservices.speech.AutoDetectSourceLanguageConfig
import com.microsoft.cognitiveservices.speech.translation.TranslationRecognitionEventArgs
import com.microsoft.cognitiveservices.speech.translation.TranslationRecognitionCanceledEventArgs
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future

/** AzureSpeechPlugin */
class AzureSpeechPlugin: FlutterPlugin, MethodCallHandler {

  private lateinit var azureChannel: MethodChannel;
  private var speechConfig: SpeechConfig? = null;
  private var audioConfig: AudioConfig? = null;
  private var reco: SpeechRecognizer? = null;
  private var translationConfig: SpeechTranslationConfig? = null;
  private var translationRecognizer: TranslationRecognizer? = null;
  private var pushStream: PushAudioInputStream? = null;
  private var handler: Handler = Handler(Looper.getMainLooper());
  private var isStopStream: Boolean = true;
  private var customPhrases: MutableList<String> = mutableListOf();
  private val maxPhraseCount = 50;
  private var recognitionTask: Future<SpeechRecognitionResult>? = null;
  
  // 保存事件监听器引用，以便移除
  private var sessionStartedHandler: EventHandler<SessionEventArgs>? = null;
  private var recognizedHandler: EventHandler<SpeechRecognitionEventArgs>? = null;
  private var recognizingHandler: EventHandler<SpeechRecognitionEventArgs>? = null;
  private var canceledHandler: EventHandler<SpeechRecognitionCanceledEventArgs>? = null;
  
  // Translation event handlers
  private var translationSessionStartedHandler: EventHandler<SessionEventArgs>? = null;
  private var translationRecognizingHandler: EventHandler<TranslationRecognitionEventArgs>? = null;
  private var translationRecognizedHandler: EventHandler<TranslationRecognitionEventArgs>? = null;
  private var translationCanceledHandler: EventHandler<TranslationRecognitionCanceledEventArgs>? = null;

  override fun onAttachedToEngine(flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
    azureChannel = MethodChannel(flutterPluginBinding.binaryMessenger, "azure_speech")
    azureChannel.setMethodCallHandler(this)
  }

  override fun onMethodCall(call: MethodCall, result: Result) {

    println("VoiceAssistant onMethodCall: ${call.method}");
    when (call.method) {

      "recognizeFromMic" -> {
        val subKey : String = "" + call.argument("subKey");
        val region : String = "" + call.argument("region");
        val language : String = "" + call.argument("language");
        val timeoutMs : String = "" + call.argument("timeout");
        recognizeFromMic(subKey, region, language, timeoutMs);
      }

      "recognizeStream" -> {
        val byteArray = call.argument("data") as? ByteArray
        val data = byteArray?.toUByteArray()?.toByteArray()
        if (data != null){
          recognizeStream(data);
        }
      }

      "stopStream" -> {
        stopStream();
      }

      "recognize" -> {
        recognize();
      }

      "setPhraseList" -> {
        val phrases = call.argument<List<String>>("phrases");
        if (phrases != null) {
          setPhraseList(phrases, result);
        } else {
          result.error("INVALID_ARGUMENT", "phrases parameter is required", null);
        }
      }

      "clearPhrases" -> {
        clearPhrases(result);
      }

      "speechWithDetect" -> {
        val subKey: String = "" + call.argument("subKey");
        val region: String = "" + call.argument("region");
        val langs: List<String>? = call.argument("langs");
        if (langs != null) {
          speechWithDetect(subKey, region, langs, result);
        } else {
          result.error("INVALID_ARGUMENT", "langs parameter is required", null);
        }
      }

      "translation" -> {
        val subKey: String = "" + call.argument("subKey");
        val region: String = "" + call.argument("region");
        val langs: List<String>? = call.argument("langs");
        if (langs != null) {
          translation(subKey, region, langs, result);
        } else {
          result.error("INVALID_ARGUMENT", "langs parameter is required", null);
        }
      }

      "dispose" -> {
        dispose();
      }

      else -> {
        result.notImplemented()
      }
    }
  }

  private fun recognizeFromMic(subKey: String, region: String, language: String, timeoutMs: String){

    try{
      dispose();
      println("azure recognition start--$language -- $region");
      speechConfig = SpeechConfig.fromSubscription(subKey, region);
      speechConfig?.speechRecognitionLanguage = language;
      speechConfig?.setProperty(PropertyId.SpeechServiceConnection_InitialSilenceTimeoutMs, timeoutMs);
      speechConfig?.setProperty(PropertyId.Speech_SegmentationSilenceTimeoutMs, "1500");
      speechConfig?.setProperty(PropertyId.SpeechServiceResponse_ProfanityOption, "raw")
      pushStream = PushAudioInputStream.create();
      audioConfig = AudioConfig.fromStreamInput(pushStream);
      reco = SpeechRecognizer(speechConfig, audioConfig);
      
      // 应用自定义短语列表
      if (customPhrases.isNotEmpty()) {
        reco?.let {
          val phraseList = PhraseListGrammar.fromRecognizer(it)
          for (phrase in customPhrases) {
            phraseList.addPhrase(phrase);
          }
//          phraseList.setWeight(2.0)
        }
      }

      // 创建并保存事件监听器引用
      sessionStartedHandler = EventHandler<SessionEventArgs> { _, _ ->
        println("azure recognition started")
        invokeMethod("speech.onRecognitionStarted", "")
      }
      
      recognizedHandler = EventHandler<SpeechRecognitionEventArgs> { _, evt->
        val text = evt.result.text;
        val reason = evt.result.reason;
        println("sentence recognized result: $text reason: $reason");
        invokeMethod("speech.onRecognized", text);
      }

      recognizingHandler = EventHandler<SpeechRecognitionEventArgs> { _, evt->
        val text = evt.result.text;
        println("azure recognition recognizing result: $text");
        invokeMethod("speech.onRecognizing", text);
      }
      
      canceledHandler = EventHandler<SpeechRecognitionCanceledEventArgs> { _, evt->
        println("azure recognition canceled: errorCode: ${evt.errorCode} errorDetails: ${evt.errorDetails}");
        invokeMethod("speech.onCancel", evt.errorDetails);
      }
      
      // 添加事件监听器
      reco?.sessionStarted?.addEventListener(sessionStartedHandler);
      reco?.recognized?.addEventListener(recognizedHandler);
      reco?.recognizing?.addEventListener(recognizingHandler);
      reco?.canceled?.addEventListener(canceledHandler);
      isStopStream = false;

    }catch(exec: Exception){
      invokeMethod("speech.onCancel", exec.message);
      println("sentence recognition Stop  ${exec.message}");
      stopStream();
    }

  }

  private fun stopStream(){
    if (!isStopStream){
      isStopStream = true;
      try {
        println("sentence Stop Stream");
        pushStream?.close();
      }catch(exec: Exception){
        println("sentence Stop Stream ${exec.message}");
      }
    }
  }

  private fun recognize() {
    println("azure recognition Start time: ${System.currentTimeMillis()}");
    reco?.let {
      recognitionTask = it.recognizeOnceAsync();
      recognitionTask?.let { task ->
        setOnTaskCompletedListener(task) { result ->
          println("azure recognition Stop time: ${System.currentTimeMillis()}");
          invokeMethod("speech.onRecognitionStop", "");
          recognitionTask = null;
        }
      }
    }
  }

  private fun recognizeStream(data : ByteArray){
    try {
      pushStream?.write(data);
    }catch(exec: Exception){
      println("sentence recognizeStream ${exec.message}");
    }
  }

  private fun speechWithDetect(subKey: String, region: String, langs: List<String>, result: Result) {
    try {
      println("speechWithDetect start with languages: $langs");
      speechConfig = SpeechConfig.fromSubscription(subKey, region);
      speechConfig?.setProperty(PropertyId.SpeechServiceConnection_InitialSilenceTimeoutMs, "5000");
      speechConfig?.setProperty(PropertyId.Speech_SegmentationSilenceTimeoutMs, "1500");
      speechConfig?.setProperty(PropertyId.SpeechServiceResponse_ProfanityOption, "raw")
      pushStream = PushAudioInputStream.create();
      audioConfig = AudioConfig.fromStreamInput(pushStream);
      val autoDetectConfig = AutoDetectSourceLanguageConfig.fromLanguages(langs);
      reco = SpeechRecognizer(speechConfig, autoDetectConfig, audioConfig); 
      
      // Setup event handlers
      sessionStartedHandler = EventHandler<SessionEventArgs> { _, _ ->
        println("azure translation session started")
        invokeMethod("speech.onRecognitionStarted", "");
      }
      
      recognizingHandler = EventHandler<SpeechRecognitionEventArgs> { _, evt ->
        val text = evt.result.text;
        val detectedLanguage = evt.result.properties?.getProperty(
            PropertyId.SpeechServiceConnection_AutoDetectSourceLanguageResult
        ) ?: "unknown";
        println("Detected recognizing: $detectedLanguage - $text");
        invokeMethod(
          "speech.onDetectedAndRecognizing",
          mapOf(
            "detectedLanguage" to detectedLanguage,
             "text" to text
          )
        )
      }
      
      recognizedHandler = EventHandler<SpeechRecognitionEventArgs> { _, evt ->
        val text = evt.result.text;
        println("azure translation recognized: $text");
        
        // Get detected source language
        val detectedLanguage = evt.result.properties?.getProperty(
            PropertyId.SpeechServiceConnection_AutoDetectSourceLanguageResult
        ) ?: "unknown";
        println("Detected language: $detectedLanguage");
        
        // Build response with detected language and translations
        val response = mapOf(
          "text" to text,
          "detectedLanguage" to detectedLanguage
        );
        invokeMethod("speech.onDetectedAndRecognized", response);
      }
      
      canceledHandler = EventHandler<SpeechRecognitionCanceledEventArgs> { _, evt ->
        println("azure speech canceled: errorCode: ${evt.errorCode} errorDetails: ${evt.errorDetails}");
        invokeMethod("speech.onCancel", "${evt.errorCode},${evt.errorDetails}");
      }
      
      // Add event listeners
      reco?.sessionStarted?.addEventListener(sessionStartedHandler);
      reco?.recognized?.addEventListener(recognizedHandler);
      reco?.recognizing?.addEventListener(recognizingHandler);
      reco?.canceled?.addEventListener(canceledHandler);
      isStopStream = false;

      val task = reco?.recognizeOnceAsync()
      task?.let { task ->
        setOnTaskCompletedListener(task) { _ ->
          println("azure translation Stop time: ${System.currentTimeMillis()}")
        }
      }
      result.success(mapOf("success" to true, "message" to "speech initialized"));
    } catch (e: Exception) {
      println("reco error: ${e.message}");
      e.printStackTrace();
      result.error("TRANSLATION_ERROR", "speech initialization failed: ${e.message}", null);
      invokeMethod("speech.onCancel", e.message);
    }
  }

  private fun translation(subKey: String, region: String, langs: List<String>, result: Result) {
    try {
      disposeTranslation();
      println("azure translation start with languages: $langs");
      
      // Create translation config
      translationConfig = SpeechTranslationConfig.fromSubscription(subKey, region);
      translationConfig?.setProperty(PropertyId.SpeechServiceConnection_InitialSilenceTimeoutMs, "13100");
      translationConfig?.setProperty(PropertyId.Speech_SegmentationSilenceTimeoutMs, "1500");
      translationConfig?.setProperty(PropertyId.SpeechServiceResponse_ProfanityOption, "raw")

      // Add target languages for translation
      for (lang in langs) {
        translationConfig?.addTargetLanguage(lang);
      }
      val autoDetectConfig = AutoDetectSourceLanguageConfig.fromLanguages(langs);
      // Create push stream and audio config
      pushStream = PushAudioInputStream.create();
      audioConfig = AudioConfig.fromStreamInput(pushStream);

      // Create translation recognizer
      translationRecognizer = TranslationRecognizer(
          translationConfig,
          autoDetectConfig,
          audioConfig
      );
      
      // Setup event handlers
      translationSessionStartedHandler = EventHandler<SessionEventArgs> { _, _ ->
        println("azure translation session started")
        invokeMethod("speech.onRecognitionStarted", "");
      }
      
      translationRecognizingHandler = EventHandler<TranslationRecognitionEventArgs> { _, evt ->
        val text = evt.result.text;
        val detectedLanguage = evt.result.properties?.getProperty(
            PropertyId.SpeechServiceConnection_AutoDetectSourceLanguageResult
        ) ?: "unknown";
        println("Detected recognizing: $detectedLanguage - $text");
        invokeMethod(
          "speech.onDetectedAndRecognizing",
          mapOf(
            "detectedLanguage" to detectedLanguage,
             "text" to text
          )
        )
      }
      
      translationRecognizedHandler = EventHandler<TranslationRecognitionEventArgs> { _, evt ->
        val text = evt.result.text;
        println("azure translation recognized: $text");
        
        // Get detected source language
        val detectedLanguage = evt.result.properties?.getProperty(
            PropertyId.SpeechServiceConnection_AutoDetectSourceLanguageResult
        ) ?: "unknown";
        println("Detected language: $detectedLanguage");
        
        // Get translations for all target languages
        val translations = mutableMapOf<String, String>();
        for (lang in langs) {
          val translation = evt.result.translations?.get(lang) ?: "";
          translations[lang] = translation;
          println("Translation to $lang: $translation");
        }
        
        // Build response with detected language and translations
        val response = mapOf(
          "text" to text,
          "detectedLanguage" to detectedLanguage,
          "translations" to translations
        );
        invokeMethod("speech.onTranslation", response);
      }
      
      translationCanceledHandler = EventHandler<TranslationRecognitionCanceledEventArgs> { _, evt ->
        println("azure translation canceled: errorCode: ${evt.errorCode} errorDetails: ${evt.errorDetails}");
        invokeMethod("speech.onCancel", "${evt.errorCode},${evt.errorDetails}");
      }
      
      // Add event listeners
      translationRecognizer?.sessionStarted?.addEventListener(translationSessionStartedHandler);
      translationRecognizer?.recognizing?.addEventListener(translationRecognizingHandler);
      translationRecognizer?.recognized?.addEventListener(translationRecognizedHandler);
      translationRecognizer?.canceled?.addEventListener(translationCanceledHandler);
      
      isStopStream = false;
      // Start a recognition operation on the translation recognizer so its event handlers fire.
      // Use recognizeOnceAsync to match the behavior of the non-translation path. If you want
      // continuous recognition, replace with startContinuousRecognitionAsync().
      val translationTask = translationRecognizer?.recognizeOnceAsync()
      translationTask?.let { task ->
        setOnTaskCompletedListener(task) { _ ->
          println("azure translation Stop time: ${System.currentTimeMillis()}")
        }
      }
      result.success(mapOf("success" to true, "message" to "Translation initialized"));
    } catch (e: Exception) {
      println("translation error: ${e.message}");
      e.printStackTrace();
      result.error("TRANSLATION_ERROR", "Translation initialization failed: ${e.message}", null);
      invokeMethod("speech.onCancel", e.message);
    }
  }

  private fun dispose(){
    try {
      // 1. 先移除所有事件监听器（这是关键！）
      reco?.let { recognizer ->
        sessionStartedHandler?.let { recognizer.sessionStarted.removeEventListener(it) }
        recognizedHandler?.let { recognizer.recognized.removeEventListener(it) }
        recognizingHandler?.let { recognizer.recognizing.removeEventListener(it) }
        canceledHandler?.let { recognizer.canceled.removeEventListener(it) }
      }
      sessionStartedHandler = null;
      recognizedHandler = null;
      recognizingHandler = null;
      canceledHandler = null;
      
      // Clean up translation recognizer
      disposeTranslation();
  
      recognitionTask?.cancel(true);
      recognitionTask = null;
      reco?.stopContinuousRecognitionAsync()?.get();
      pushStream?.close();
      pushStream = null;
      
      // reco?.close();
      reco = null;
      
      audioConfig?.close();
      audioConfig = null;
      
      speechConfig?.close();
      speechConfig = null;
      
      isStopStream = true;
      println("azure recognition disposed");
    } catch (e: Exception) {
      println("dispose error: ${e.message}");
      e.printStackTrace();
    }
  }

  private fun disposeTranslation() {
    try {
      // Remove translation event listeners
      translationRecognizer?.let { recognizer ->
        translationSessionStartedHandler?.let { recognizer.sessionStarted.removeEventListener(it) }
        translationRecognizingHandler?.let { recognizer.recognizing.removeEventListener(it) }
        translationRecognizedHandler?.let { recognizer.recognized.removeEventListener(it) }
        translationCanceledHandler?.let { recognizer.canceled.removeEventListener(it) }
      }
      translationSessionStartedHandler = null;
      translationRecognizingHandler = null;
      translationRecognizedHandler = null;
      translationCanceledHandler = null;
      
      translationRecognizer?.stopContinuousRecognitionAsync()?.get();
      translationRecognizer = null;
      
      translationConfig?.close();
      translationConfig = null;
      
      println("Translation disposed");
    } catch (e: Exception) {
      println("disposeTranslation error: ${e.message}");
      e.printStackTrace();
    }
  }

  private val s_executorService: ExecutorService = Executors.newCachedThreadPool();

  private fun <T> setOnTaskCompletedListener(task: Future<T>, listener: (T) -> Unit) {
    s_executorService.submit {
      val result = task.get()
      listener(result)
    };
  }

  /**
   * 设置短语列表，提高识别准确率
   * @param phrases 短语列表
   * @param result Flutter方法调用结果
   */
  private fun setPhraseList(phrases: List<String>, result: Result) {
    try {
      if (phrases.size > maxPhraseCount) {
        result.error("PHRASE_LIMIT_EXCEEDED", "短语数量不能超过 $maxPhraseCount 个", null);
        return;
      }
      
      customPhrases.clear();
      customPhrases.addAll(phrases);
      
      result.success(mapOf(
        "success" to true,
        "count" to customPhrases.size,
        "message" to "短语列表设置成功"
      ));
      
    } catch (e: Exception) {
      result.error("SET_PHRASE_ERROR", "设置短语列表失败: ${e.message}", null);
    }
  }



  /**
   * 清空所有短语
   * @param result Flutter方法调用结果
   */
  private fun clearPhrases(result: Result) {
    try {
      customPhrases.clear();
      result.success(mapOf(
        "success" to true,
        "count" to 0,
        "message" to "短语列表已清空"
      ));
    } catch (e: Exception) {
      result.error("CLEAR_PHRASES_ERROR", "清空短语失败: ${e.message}", null);
    }
  }



  private fun invokeMethod(method: String, arguments: Any?) {

    handler.post {
      azureChannel.invokeMethod(method, arguments);
    }
  }

  override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
    azureChannel.setMethodCallHandler(null)
  }
}
