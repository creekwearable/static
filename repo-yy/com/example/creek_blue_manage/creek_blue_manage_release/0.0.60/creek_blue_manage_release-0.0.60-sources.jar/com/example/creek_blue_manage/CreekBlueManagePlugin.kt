package com.example.creek_blue_manage

import android.Manifest
import android.R
import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.util.Log
import androidx.annotation.NonNull
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import java.util.HashMap
import java.util.Map
import java.util.TimeZone
import android.os.Handler      // ✅ 必须
import android.os.Looper       // ✅ 必须
import io.flutter.plugin.common.BinaryMessenger


object CreekMethodChannelHolder {

    @Volatile
    var channel: MethodChannel? = null
        private set

    fun init(messenger: BinaryMessenger) {
        if (channel == null) {
            channel = MethodChannel(messenger, "creek_blue_manage")
        }
    }

    fun send(method: String, args: Any?) {
        val ch = channel ?: return
        Handler(Looper.getMainLooper()).post {
            ch.invokeMethod(method, args)
        }
    }
}


/** CreekBlueManagePlugin */
class CreekBlueManagePlugin :
    FlutterPlugin,
    ActivityAware,
    Application.ActivityLifecycleCallbacks,
    MethodCallHandler {

    private lateinit var channel: MethodChannel
    private var application: Application? = null

    private var resumedCount = 0
    private var isForeground = false
    private var context: Context? = null
    private var activity: Activity? = null
    private var pendingCalendarPermissionResult: Result? = null
    private var phoneStateReceiver: CreekPhoneStateReceiver? = null

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel = MethodChannel(binding.binaryMessenger, "creek_blue_manage")
        channel.setMethodCallHandler(this)
        CreekMethodChannelHolder.init(binding.binaryMessenger)
        context = binding.applicationContext
        application = binding.applicationContext as Application
        application?.registerActivityLifecycleCallbacks(this)
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "getPlatformVersion" -> {
                result.success("Android ${android.os.Build.VERSION.RELEASE}")
            }

            "endCall" -> {
                endCall()
                result.success(null)
            }

            "requestPermission" -> {
                requestPermission()
                result.success(null)
            }

            "sendSms" -> {
                Log.d("sendSms", "${call.arguments}")
                val arguments = call.arguments as? Map<String, Any>
                if (arguments != null) {
                    val number = arguments["phoneNumber"] as? String
                    val message = arguments["message"] as? String
                    val slotId = arguments["simSlot"] as? Int
                    if (number != null && message != null && slotId != null) {
                        sendSms(number, message, slotId)
                        result.success("SMS sent successfully")
                    } else {
                        result.error("INVALID_ARGUMENTS", "Invalid arguments provided", null)
                    }
                } else {
                    result.error("INVALID_ARGUMENTS", "Arguments are not a map", null)
                }
            }

            "isContactPermissionGranted" -> {
                // 检查通讯录权限是否已开启
                val isGranted = isContactPermissionGranted()
                result.success(isGranted)
            }

            "isSmsPermissionGranted" -> {
                val isGranted = isSmsPermissionGranted()
                result.success(isGranted)
            }

            "getTimeZoneName" -> {
                val timeZoneId = TimeZone.getDefault().id
                result.success(timeZoneId)
            }

            "requestCalendarPermissions" -> {
                // 请求日历权限
                pendingCalendarPermissionResult = result
                requestCalendarPermissions()
            }

            "isCalendarPermissionGranted" -> {
                // 检查日历权限是否开启
                val isGranted = isCalendarPermissionGranted()
                result.success(isGranted)
            }

            "getAppLifecycleState" -> {
                result.success(if (isForeground) "foreground" else "background")
            }
            "registerPhoneState" -> {
                registerPhoneStateReceiver()
                result.success(null)
            }
            else -> {
                result.notImplemented()
            }
        }
    }

    private fun registerPhoneStateReceiver() {
        if (phoneStateReceiver != null) return
        if (context == null) return

        phoneStateReceiver = CreekPhoneStateReceiver()
        val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        context!!.registerReceiver(phoneStateReceiver, filter)
    }

    // 新增方法：检查日历权限是否已开启
    private fun isCalendarPermissionGranted(): Boolean {
        return context?.let {
            ContextCompat.checkSelfPermission(
                it,
                Manifest.permission.READ_CALENDAR
            ) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(
                        it,
                        Manifest.permission.WRITE_CALENDAR
                    ) == PackageManager.PERMISSION_GRANTED
        } ?: false
    }

    // 新增方法：请求日历权限
    private fun requestCalendarPermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR
        )
        val permissionsToRequest = permissions.filter {
            context?.let { ctx -> ContextCompat.checkSelfPermission(ctx, it) } != PackageManager.PERMISSION_GRANTED
        }
        if (permissionsToRequest.isNotEmpty()) {
            activity?.let { ActivityCompat.requestPermissions(it, permissionsToRequest.toTypedArray(), 2) }
        } else {
            pendingCalendarPermissionResult?.success(true)
            pendingCalendarPermissionResult = null
        }
    }

    // 新增方法：检查通讯录权限是否已开启
    private fun isContactPermissionGranted(): Boolean {
        return context?.let {
            ContextCompat.checkSelfPermission(it, Manifest.permission.READ_CONTACTS)
        } == PackageManager.PERMISSION_GRANTED
    }

    private fun isSmsPermissionGranted(): Boolean {
        return context?.let {
            ContextCompat.checkSelfPermission(it, Manifest.permission.SEND_SMS)
        } == PackageManager.PERMISSION_GRANTED
    }

    private fun endCall() {
        val permissionCheck = context?.let { ContextCompat.checkSelfPermission(it, Manifest.permission.CALL_PHONE) }
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            try {
                val telephonyManager = context?.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
                val clazz = Class.forName(telephonyManager.javaClass.name)
                val method = clazz.getDeclaredMethod("getITelephony")
                method.isAccessible = true
                val telephonyInterface = method.invoke(telephonyManager)
                val iTelephonyClass = Class.forName("com.android.internal.telephony.ITelephony")
                val telephonyService = iTelephonyClass.cast(telephonyInterface)
                val endCallMethod = iTelephonyClass.getDeclaredMethod("endCall")
                endCallMethod.invoke(telephonyService)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun requestPermission() {
        val permissions = arrayOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG
        )
        val permissionsToRequest = permissions.filter {
            context?.let { ctx -> ContextCompat.checkSelfPermission(ctx, it) } != PackageManager.PERMISSION_GRANTED
        }
        if (permissionsToRequest.isNotEmpty()) {
            activity?.let { ActivityCompat.requestPermissions(it, permissionsToRequest.toTypedArray(), 1) }
        }
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP_MR1)
    private fun sendSms(number: String?, message: String?, slotId: Int?) {
        if (number != null && message != null && slotId != null) {
            val subscriptionManager =
                context!!.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            val subscriptionInfoList = subscriptionManager.activeSubscriptionInfoList
            var foundSubscription = false
            for (subscriptionInfo in subscriptionInfoList) {
                val simSlotIndex = subscriptionInfo.simSlotIndex
                if (simSlotIndex == slotId) {
                    val subscriptionId = subscriptionInfo.subscriptionId
                    val smsManager = SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
                    smsManager.sendTextMessage(number, null, message, null, null)
                    Log.d("SMS", "Message sent from SIM slot: $slotId")
                    break
                }
            }
            if (!foundSubscription) {
                // 如果没有找到指定卡槽，使用默认的SmsManager发送短信
                val defaultSmsManager = SmsManager.getDefault()
                defaultSmsManager.sendTextMessage(number, null, message, null, null)
                Log.d("SMS", "Default SMS Manager used to send message")
            }
        }

    }


    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        activity = binding.activity
    }

    override fun onDetachedFromActivityForConfigChanges() {
        activity = null
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        activity = binding.activity
    }

    override fun onDetachedFromActivity() {
        activity = null
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        application?.unregisterActivityLifecycleCallbacks(this)
        channel.setMethodCallHandler(null)
    }

    // Activity 前后台判断核心逻辑
    override fun onActivityResumed(activity: Activity) {
        resumedCount++
        if (!isForeground && resumedCount > 0) {
            isForeground = true
            notifyFlutter(true)
        }
    }

    override fun onActivityPaused(activity: Activity) {
        resumedCount--
        if (resumedCount <= 0) {
            resumedCount = 0
            if (isForeground) {
                isForeground = false
                notifyFlutter(false)
            }
        }
    }

    // 必须实现但无需处理的生命周期空方法
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityStarted(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {}

    // 通知 Flutter 的私有方法
    private fun notifyFlutter(foreground: Boolean) {
        channel.invokeMethod(
            "onAppLifecycleChanged",
            mapOf("foreground" to foreground)
        )
    }
}