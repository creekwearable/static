//
//  CreekInterFace.swift
//  CreekSDK
//
//  Created by bean on 2023/6/28.
//

import Foundation


 open class CreekInterFace: CreekSDK {
    
    

}
