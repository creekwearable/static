// Copyright 2017, Paul DeMarco.
// All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

package com.boskokg.flutter_blue_plus;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Application;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHeadset;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.util.Log;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import java.lang.reflect.Method;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.embedding.engine.plugins.activity.ActivityAware;
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding;
import io.flutter.plugin.common.BinaryMessenger;
import io.flutter.plugin.common.EventChannel;
import io.flutter.plugin.common.EventChannel.EventSink;
import io.flutter.plugin.common.EventChannel.StreamHandler;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;
import io.flutter.plugin.common.PluginRegistry.RequestPermissionsResultListener;

import android.os.Build;

public class FlutterBluePlusPlugin implements FlutterPlugin, MethodCallHandler, RequestPermissionsResultListener, ActivityAware {

    private static final String TAG = "FlutterBluePlugin";
    private final Object initializationLock = new Object();
    private final Object tearDownLock = new Object();
    private Context context;
    private MethodChannel channel;
    private static final String NAMESPACE = "flutter_blue_plus";

    private EventChannel stateChannel;
    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;

    private BluetoothSocket bluetoothSocket;
    private InputStream inputStream;
    private OutputStream outputStream;

    private DataReceivedListener dataReceivedListener;
    private boolean isListening;
    private Thread listeningThread;

    private FlutterPluginBinding pluginBinding;
    private ActivityPluginBinding activityBinding;
    private boolean isConnecting = false;
    private boolean isSPPConnect = false;

    private String deviceID = "";

    static final private UUID CCCD_ID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");//默认UUID

    // GATT 回调与 MethodChannel 可能运行在不同线程，使用并发 Map 避免断线重连时读写竞争。
    private final Map<String, BluetoothDeviceCache> mDevices = new ConcurrentHashMap<>();
    private LogLevel logLevel = LogLevel.EMERGENCY;

    private interface OperationOnPermission {
        void op(boolean granted, String permission);
    }

    private int lastEventId = 1452;
    private final Map<Integer, OperationOnPermission> operationsOnPermission = new HashMap<>();

    private final Set<String> macDeviceScanned = new HashSet<>();
    private boolean allowDuplicates = false;

    public interface DeviceBack {
        void onDeviceBack(BluetoothDevice model);
    }
    private DeviceBack baseDevice;

    public FlutterBluePlusPlugin() {}

    public interface DataReceivedListener {
        void onDataReceived(byte[] data);

        void onConnectionLost();

    }
    public void setDataReceivedListener(DataReceivedListener listener) {
        this.dataReceivedListener = listener;
    }

    public void startListening() {
        isListening = true;
        listeningThread = new Thread(() -> {
            byte[] buffer = new byte[1024];
            int bytes;
            while (isListening) {
                try {
                    InputStream localInputStream;
                    synchronized (this) {
                        if (inputStream == null) break;
                        localInputStream = inputStream;
                    }
                    bytes = localInputStream.read(buffer);
                    if (dataReceivedListener != null) {
                        dataReceivedListener.onDataReceived(Arrays.copyOfRange(buffer, 0, bytes));
                    }
                } catch (IOException e) {
                    if (isListening && dataReceivedListener != null) {
                        dataReceivedListener.onConnectionLost();
                    }
                    closeConnection();
                    break;
                }catch (Exception e) { // ✅ 捕获 NullPointerException 和其他异常
                    if (isListening && dataReceivedListener != null) {
                        dataReceivedListener.onConnectionLost();
                    }
                    closeConnection();
                    break;
                }
            }
        });
        listeningThread.start();
    }

    public void stopListening() {
        isListening = false;
        if (inputStream != null) {
            try {
                inputStream.close(); // 触发 read() 中断
            } catch (IOException e) {
                Log.e(TAG, "关闭输入流失败", e);
            }
        }
        if (listeningThread != null && listeningThread.isAlive()) {
            listeningThread.interrupt();
        }
    }

    public synchronized void closeConnection() {
        Log.d(TAG, "closeConnection");
        isSPPConnect = false;
        isConnecting = false;
        try {
            stopListening();
            if (inputStream != null) inputStream.close();
            if (outputStream != null) outputStream.close();
            if (bluetoothSocket != null) bluetoothSocket.close();
            inputStream = null;
            outputStream = null;
            bluetoothSocket = null;
        } catch (IOException e) {

        }


    }
    @Override
    public void onAttachedToEngine(@NonNull FlutterPluginBinding flutterPluginBinding) {
        Log.d(TAG, "onAttachedToEngine");
        pluginBinding = flutterPluginBinding;
        setup(pluginBinding.getBinaryMessenger(),
                (Application) pluginBinding.getApplicationContext());
    }

    @Override
    public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) {
        Log.d(TAG, "onDetachedFromEngine");
        // pluginBinding = null;
        // tearDown();
    }

    @Override
    public void onAttachedToActivity(@NonNull ActivityPluginBinding binding) {
        Log.d(TAG, "onAttachedToActivity");
        activityBinding = binding;
        activityBinding.addRequestPermissionsResultListener(this);
    }

    @Override
    public void onDetachedFromActivityForConfigChanges() {
        Log.d(TAG, "onDetachedFromActivityForConfigChanges");
        onDetachedFromActivity();
    }

    @Override
    public void onReattachedToActivityForConfigChanges(@NonNull ActivityPluginBinding binding) {
        Log.d(TAG, "onReattachedToActivityForConfigChanges");
        onAttachedToActivity(binding);
    }

    @Override
    public void onDetachedFromActivity() {
        Log.d(TAG, "onDetachedFromActivity");
        activityBinding.removeRequestPermissionsResultListener(this);
        activityBinding = null;
    }

    private void setup(
            final BinaryMessenger messenger,
            final Application application) {
        synchronized (initializationLock) {
            Log.d(TAG, "setup");
            this.context = application;
            channel = new MethodChannel(messenger, NAMESPACE + "/methods");
            channel.setMethodCallHandler(this);
            stateChannel = new EventChannel(messenger, NAMESPACE + "/state");
            stateChannel.setStreamHandler(stateHandler);
            mBluetoothManager = (BluetoothManager) application.getSystemService(Context.BLUETOOTH_SERVICE);
            mBluetoothAdapter = mBluetoothManager.getAdapter();
            // 注册广播接收器
            IntentFilter filter = new IntentFilter();
            filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
            context.registerReceiver(bluetoothReceiver, filter);
        }
    }

    // 广播接收器
    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
//                Log.d("11111", "蓝牙设备已连接，开始进行SPP连接");
//                invokeMethodUIThread2("blueLog", "蓝牙设备已连接，开始进行SPP连接");
//                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
//                try {
//                    startSppConnection(device);
//                } catch (IOException e) {
//                    throw new RuntimeException(e);
//                }
            }
        }
    };
    private void startSppConnection(BluetoothDevice device) throws IOException {


        Log.d("11111", "startSppConnection:isConnecting=" + isConnecting + "isSPPConnect=" + isSPPConnect);

        invokeMethodUIThread2("blueLog", "startSppConnection:isConnecting=" + isConnecting + "isSPPConnect=" + isSPPConnect);

        if (isConnecting || isSPPConnect) return;
        Log.d("11111", "device.getAddress()=" + device.getAddress());
        invokeMethodUIThread2("blueLog", "device.getAddress()=" + device.getAddress());
        Log.d("11111", "deviceID：" + deviceID);
        invokeMethodUIThread2("blueLog", "deviceID：" + deviceID);
        if (!device.getAddress().equals(deviceID)) return;
        Log.d("11111", "SPP开始连接蓝牙设备信息：" + device.toString());
        invokeMethodUIThread2("blueLog", "SPP开始连接蓝牙设备信息：" + device.toString());
        if (bluetoothSocket != null) {
            bluetoothSocket.close();
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    bluetoothSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                    //mBluetoothAdapter.cancelDiscovery();
                    inputStream = bluetoothSocket.getInputStream();
                    outputStream = bluetoothSocket.getOutputStream();
                    bluetoothSocket.connect();
                    isSPPConnect = true;

                    Log.d("11111", "SPP连接成功");
                    invokeMethodUIThread2("blueLog", "SPP连接成功");
                    invokeMethodUIThread("SppDeviceState", ProtoMaker.from(device, 2).toByteArray());

                    // 获取BluetoothHeadset实例并检查HFP连接状态
                    BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                    BluetoothProfile.ServiceListener listener = new BluetoothProfile.ServiceListener() {
                        public void onServiceConnected(int profile, BluetoothProfile proxy) {
                            if (profile == BluetoothProfile.HEADSET) {
                                BluetoothHeadset headset = (BluetoothHeadset) proxy;
                                int connectionState = headset.getConnectionState(device);
                                Log.d("11111", "当前HFP连接状态: " + connectionState);
                                invokeMethodUIThread2("blueLog", "当前HFP连接状态: " + connectionState);


                                if (connectionState != BluetoothHeadset.STATE_CONNECTED) {
                                    try {
                                        Method connectMethod = BluetoothHeadset.class.getMethod("connect", BluetoothDevice.class);
                                        boolean success = (boolean) connectMethod.invoke(headset, device);
                                        if (success) {
                                            invokeMethodUIThread2("blueLog", "HFP连接请求已发送");
                                            Log.d("11111", "HFP连接请求已发送");
                                        } else {
                                            invokeMethodUIThread2("blueLog", "HFP连接请求失败");
                                            Log.e("11111", "HFP连接请求失败");
                                        }
                                    } catch (NoSuchMethodException e) {
                                        invokeMethodUIThread2("blueLog", "没有找到connect方法");
                                        Log.e("11111", "没有找到connect方法", e);
                                    } catch (IllegalAccessException e) {
                                        invokeMethodUIThread2("blueLog", "无法访问connect方法");
                                        Log.e("11111", "无法访问connect方法", e);
                                    } catch (InvocationTargetException e) {
                                        invokeMethodUIThread2("blueLog", "反射调用connect方法失败");
                                        Log.e("11111", "反射调用connect方法失败", e);
                                    }
                                } else {
                                    invokeMethodUIThread2("blueLog", "HFP已经连接");
                                    Log.d("11111", "HFP已经连接");
                                }
                            }
                        }

                        public void onServiceDisconnected(int profile) {
                            // 服务断开时处理
                        }
                    };
                    adapter.getProfileProxy(context, listener, BluetoothProfile.HEADSET);

                    setDataReceivedListener(new DataReceivedListener() {
                        @Override
                        public void onDataReceived(byte[] data) {

                            invokeMethodUIThread("dataSPP", data);
                        }

                        @Override
                        public void onConnectionLost() {
                            Log.d(TAG, "连接失败");
                            closeConnection();
                            invokeMethodUIThread("DeviceState", ProtoMaker.from(device, 0).toByteArray());
                        }
                    });
                    startListening();

                } catch (IOException e) {
                    isConnecting = false;
                    invokeMethodUIThread2("blueLog", "SPP连接失败" + e.toString());
                    Log.d("11111", "SPP连接失败" + e.toString());
                    closeConnection();
                } catch (Exception e) {
                    isConnecting = false;
                    invokeMethodUIThread2("blueLog", "SPP连接失败" + e.toString());
                    Log.d("11111", "SPP连接失败" + e.toString());
                    closeConnection();
                }
            }
        }).start();

    }


    private void tearDown() {
        synchronized (tearDownLock) {
            Log.d(TAG, "teardown");
            context = null;
            channel.setMethodCallHandler(null);
            channel = null;
            stateChannel.setStreamHandler(null);
            stateChannel = null;
            mBluetoothAdapter = null;
            mBluetoothManager = null;
        }
    }

    @Override
    public boolean onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        OperationOnPermission operation = operationsOnPermission.get(requestCode);
        if (operation != null && grantResults.length > 0) {
            operation.op(grantResults[0] == PackageManager.PERMISSION_GRANTED, permissions[0]);
            return true;
        }
        return false;
    }

    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull Result result) {
        if(mBluetoothAdapter == null && !"isAvailable".equals(call.method)) {
            result.error("bluetooth_unavailable", "the device does not have bluetooth", null);
            return;
        }

        switch (call.method) {
            case "setLogLevel":
            {
                int logLevelIndex = (int)call.arguments;
                logLevel = LogLevel.values()[logLevelIndex];
                result.success(null);
                break;
            }

            case "state":
            {
                Protos.BluetoothState.Builder p = Protos.BluetoothState.newBuilder();
                try {
                    switch(mBluetoothAdapter.getState()) {
                        case BluetoothAdapter.STATE_OFF:
                            p.setState(Protos.BluetoothState.State.OFF);
                            break;
                        case BluetoothAdapter.STATE_ON:
                            p.setState(Protos.BluetoothState.State.ON);
                            break;
                        case BluetoothAdapter.STATE_TURNING_OFF:
                            p.setState(Protos.BluetoothState.State.TURNING_OFF);
                            break;
                        case BluetoothAdapter.STATE_TURNING_ON:
                            p.setState(Protos.BluetoothState.State.TURNING_ON);
                            break;
                        default:
                            p.setState(Protos.BluetoothState.State.UNKNOWN);
                            break;
                    }
                } catch (SecurityException e) {
                    p.setState(Protos.BluetoothState.State.UNAUTHORIZED);
                }
                result.success(p.build().toByteArray());
                break;
            }

            case "isAvailable":
            {
                result.success(mBluetoothAdapter != null);
                break;
            }

            case "isOn":
            {
                result.success(mBluetoothAdapter.isEnabled());
                break;
            }

            case "name":
            {
                String name = mBluetoothAdapter.getName();
                if (name == null)
                    name = "";
                result.success(name);
                break;
            }

            case "turnOn":
            {
                if (!mBluetoothAdapter.isEnabled()) {
                    result.success(mBluetoothAdapter.enable());
                }
                break;
            }

            case "turnOff":
            {
                if (mBluetoothAdapter.isEnabled()) {
                    result.success(mBluetoothAdapter.disable());
                }
                break;
            }

            case "startScan":
            {

                ensurePermissionBeforeAction(Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? Manifest.permission.BLUETOOTH_SCAN : Manifest.permission.ACCESS_FINE_LOCATION, (grantedScan, permissionScan) -> {
                    if (grantedScan) {
                        ensurePermissionBeforeAction(Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? Manifest.permission.BLUETOOTH_CONNECT : null, (grantedConnect, permissionConnect) -> {
                            if (grantedConnect){
                                startScan(call, result);
                            }
                            else {
                                result.error(
                                        "no_permissions", String.format("flutter_blue plugin requires %s for scanning", permissionConnect), null);
                            }
                        });
                    }
                    else
                        result.error(
                                "no_permissions", String.format("flutter_blue plugin requires %s for scanning", permissionScan), null);
                });
                break;
            }

            case "stopScan":
            {
                stopScan();
                result.success(null);
                break;
            }

            case "getConnectedDevices":
            {
                ensurePermissionBeforeAction(Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? Manifest.permission.BLUETOOTH_CONNECT : null, (granted, permission) -> {
                    if (!granted) {
                        result.error(
                                "no_permissions", String.format("flutter_blue plugin requires %s for obtaining connected devices", permission), null);
                        return;
                    }
                    List<BluetoothDevice> devices = mBluetoothManager.getConnectedDevices(BluetoothProfile.GATT);
                    Protos.ConnectedDevicesResponse.Builder p = Protos.ConnectedDevicesResponse.newBuilder();
                    for (BluetoothDevice d : devices) {
                        p.addDevices(ProtoMaker.from(d));
                    }
                    result.success(p.build().toByteArray());
                    log(LogLevel.EMERGENCY, "mDevices size: " + mDevices.size());
                });
                break;
            }

            case "getBondedDevices":
            {
                final Set<BluetoothDevice> bondedDevices = mBluetoothAdapter.getBondedDevices();
                Protos.ConnectedDevicesResponse.Builder p = Protos.ConnectedDevicesResponse.newBuilder();
                for (BluetoothDevice d : bondedDevices) {
                    p.addDevices(ProtoMaker.from(d));
                }
                result.success(p.build().toByteArray());
                log(LogLevel.EMERGENCY, "mDevices size: " + mDevices.size());
                break;
            }

            case "connect":
            {
                ensurePermissionBeforeAction(Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? Manifest.permission.BLUETOOTH_CONNECT : null, (granted, permission) -> {
                    if (!granted) {
                        invokeMethodUIThread2("blueLog", "invokeMethodUIThread  no_permissions");
                        result.error(
                                "no_permissions", String.format("flutter_blue plugin requires %s for new connection", permission), null);
                        return;
                    }
                    invokeMethodUIThread2("blueLog", "invokeMethodUIThread connect1");

                    byte[] data = call.arguments();
                    Protos.ConnectRequest options;
                    try {
                        options = Protos.ConnectRequest.newBuilder().mergeFrom(data).build();
                    } catch (InvalidProtocolBufferException e) {
                        result.error("RuntimeException", e.getMessage(), e);
                        return;
                    }
                    String deviceId = options.getRemoteId();
                    BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(deviceId);
                    BluetoothDeviceCache bluetoothDeviceCache = mDevices.get(deviceId);

                    // isConnecting 只用于状态展示，不能作为拒绝新连接的依据。Android 某些异常链路
                    // 不会返回断开回调，如果在这里直接忽略，之后所有连接都会等待一个不存在的结果。
                    if (isConnecting) {
                        invokeMethodUIThread2("blueLog", "connect requested while previous GATT is still connecting; replacing stale attempt");
                    }

                    // BLE软重启逻辑
                    boolean needSoftRestart = false;
                    BluetoothGatt oldGatt = null;
                    if (bluetoothDeviceCache != null && bluetoothDeviceCache.gatt != null) {
                        oldGatt = bluetoothDeviceCache.gatt;
                        needSoftRestart = true;
                    }
                    if (needSoftRestart && oldGatt != null) {
                        try {
                            invokeMethodUIThread2("blueLog", "BLE软重启: disconnect+refresh+close");
                            // 断开
                            oldGatt.disconnect();
                            // 调用refresh
                            try {
                                Method refreshMethod = oldGatt.getClass().getMethod("refresh");
                                boolean refreshed = (Boolean) refreshMethod.invoke(oldGatt);
                                Log.d(TAG, "refresh() called, result: " + refreshed);
                                invokeMethodUIThread2("blueLog", "refresh() called, result: " + refreshed);
                            } catch (Exception e) {
                                Log.e(TAG, "refresh() failed: " + e);
                                invokeMethodUIThread2("blueLog", "refresh() failed: " + e);
                            }
                            // 关闭
                            oldGatt.close();
                            // 移除缓存
                            removeGattIfCurrent(deviceId, oldGatt);
                        } catch (Exception e) {
                            Log.e(TAG, "BLE软重启异常: " + e);
                            invokeMethodUIThread2("blueLog", "BLE软重启异常: " + e);
                        }
                        // 延迟再发起连接
                        try {
                            Thread.sleep(300);
                        } catch (InterruptedException e) {
                            Log.e(TAG, "BLE软重启 sleep 异常: " + e);
                            invokeMethodUIThread2("blueLog", "BLE软重启 sleep 异常: " + e);
                        }
                    }

                    invokeMethodUIThread2("blueLog", "invokeMethodUIThread connect2");
                    // 新的请求，发起GATT连接并加入Map
                    BluetoothGatt gattServer;
                    isConnecting = true;
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            gattServer = device.connectGatt(context, options.getAndroidAutoConnect(), mGattCallback, BluetoothDevice.TRANSPORT_LE);
                        } else {
                            gattServer = device.connectGatt(context, options.getAndroidAutoConnect(), mGattCallback);
                        }
                        if (gattServer == null) {
                            throw new IllegalStateException("connectGatt returned null");
                        }
                        mDevices.put(deviceId, new BluetoothDeviceCache(gattServer));
                        invokeMethodUIThread2("blueLog", "connect end" + mDevices.size());
                        result.success(null);
                    } catch (Exception e) {
                        Log.e(TAG, "connectGatt error: " + e);
                        invokeMethodUIThread2("blueLog", "connectGatt error: " + e);
                        isConnecting = false;
                        result.error("connectGatt_error", e.getMessage(), e);
                    }
                });
                break;
            }

            case "sppConnect":
            {
                byte[] data = call.arguments();
                Protos.ConnectRequest options;
                try {
                    options = Protos.ConnectRequest.newBuilder().mergeFrom(data).build();
                } catch (InvalidProtocolBufferException e) {
                    result.error("RuntimeException", e.getMessage(), e);
                    return;
                }
                String deviceId = options.getRemoteId();
                BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(deviceId);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if (device.getBondState() != BluetoothDevice.BOND_BONDED) {
                            try {
                                Method createBondMethod = BluetoothDevice.class.getMethod("createBond", int.class);
                                Boolean returnValue = (Boolean) createBondMethod.invoke(device, BluetoothDevice.TRANSPORT_BREDR);
                                if (returnValue) {
                                    deviceID = device.getAddress();
                                    Log.d(TAG, "配对成功...");
//                  try {
//                    startSppConnection(device);
//                  } catch (IOException e) {
//                    throw new RuntimeException(e);
//                  }

                                }
                            } catch (Exception e) {
                                result.error("createSocket", e.getMessage(), e);

                            }
                        } else {
                            try {
                                bluetoothSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                                mBluetoothAdapter.cancelDiscovery();
                                inputStream = bluetoothSocket.getInputStream();
                                outputStream = bluetoothSocket.getOutputStream();
                                bluetoothSocket.connect();
                                isSPPConnect = true;
                                Log.d("11111", "SPP连接成功");
                                invokeMethodUIThread2("blueLog", "SPP连接成功");
                                deviceID = device.getAddress();
                                invokeMethodUIThread("SppDeviceState", ProtoMaker.from(device, 2).toByteArray());

                                // 获取BluetoothHeadset实例并检查HFP连接状态
                                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                                if (adapter != null && adapter.getProfileConnectionState(BluetoothProfile.HEADSET) == BluetoothProfile.STATE_CONNECTED) {
                                    invokeMethodUIThread2("blueLog", "设备支持HFP");
                                    Log.d("11111", "设备支持HFP");
                                } else {
                                    invokeMethodUIThread2("blueLog", "设备不支持HFP");
                                    Log.e("11111", "设备不支持HFP");
                                }
                                BluetoothProfile.ServiceListener listener = new BluetoothProfile.ServiceListener() {
                                    public void onServiceConnected(int profile, BluetoothProfile proxy) {
                                        if (profile == BluetoothProfile.HEADSET) {
                                            BluetoothHeadset headset = (BluetoothHeadset) proxy;
                                            int connectionState = headset.getConnectionState(device);
                                            Log.d("11111", "当前HFP连接状态: " + connectionState);

                                            if (connectionState != BluetoothHeadset.STATE_CONNECTED) {
                                                try {
                                                    Method connectMethod = BluetoothHeadset.class.getMethod("connect", BluetoothDevice.class);
                                                    boolean success = (boolean) connectMethod.invoke(headset, device);
                                                    if (success) {
                                                        Log.d("11111", "HFP连接请求已发送");
                                                    } else {
                                                        Log.e("11111", "HFP连接请求失败");
                                                    }
                                                } catch (NoSuchMethodException e) {
                                                    Log.e("11111", "没有找到connect方法", e);
                                                } catch (IllegalAccessException e) {
                                                    Log.e("11111", "无法访问connect方法", e);
                                                } catch (InvocationTargetException e) {
                                                    Log.e("11111", "反射调用connect方法失败", e);
                                                }
                                            } else {
                                                Log.d("11111", "HFP已经连接");
                                            }
                                        }
                                    }

                                    public void onServiceDisconnected(int profile) {
                                        // 服务断开时处理
                                    }
                                };
                                adapter.getProfileProxy(context, listener, BluetoothProfile.HEADSET);
                                setDataReceivedListener(new DataReceivedListener() {
                                    @Override
                                    public void onDataReceived(byte[] data) {
                                        invokeMethodUIThread("dataSPP", data);
                                    }

                                    @Override
                                    public void onConnectionLost() {
                                        Log.d(TAG, "连接失败");
                                        closeConnection();
                                        invokeMethodUIThread("SppDeviceState", ProtoMaker.from(device, 0).toByteArray());
                                    }
                                });
                                startListening();

                            } catch (IOException e) {
                                Log.d("11111", "SPP连接错误：" + e.toString());
                                invokeMethodUIThread2("blueLog", "SPP连接错误：" + e.toString());
                                invokeMethodUIThread("SppDeviceState", ProtoMaker.from(device, 0).toByteArray());

//                                            result.error("reconnect_error", "connect fail", null);
                                isConnecting = false;
                                closeConnection();
                                return;
                            } catch (Exception e) {
                                closeConnection();
                                isConnecting = false;
                                Log.d("11111", "SPP连接错误：" + e.toString());
                                invokeMethodUIThread2("blueLog", "SPP连接错误：" + e.toString());
                                invokeMethodUIThread("SppDeviceState", ProtoMaker.from(device, 0).toByteArray());
//                                            result.error("reconnect_error", "connect fail", null);
                                return;
                            }

                        }
                    }
                }).

                        start();
            }

            case "pair":
            {
                Object arg = call.arguments;
                String deviceId;
                if (arg instanceof String) {
                    deviceId = ((String) arg).trim();
                } else if (arg instanceof byte[]) {
                    deviceId = new String((byte[]) arg); // 可能需要指定编码 UTF-8
                } else {
                    result.error("INVALID_ARGUMENT", "Expected String or byte[], but got: " + arg.getClass().getName(), null);
                    return;
                }
                if (!BluetoothAdapter.checkBluetoothAddress(deviceId)) {
                    result.error("INVALID_ADDRESS", "Invalid Bluetooth address: " + deviceId, null);
                    return;
                }
                BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(deviceId);
                device.createBond();
                result.success(null);
                break;
            }

            case "clearGattCache":
            {
                String deviceId = (String)call.arguments;
                BluetoothDeviceCache cache = mDevices.get(deviceId);

                Boolean hasCleared = false;

                if (cache != null) {
                    BluetoothGatt gattServer = cache.gatt;
                    try {
                        final Method refresh = gattServer.getClass().getMethod("refresh");
                        if (refresh != null){
                            hasCleared = (Boolean) refresh.invoke(gattServer);
                        }
                    }catch (Exception e){
                        Log.d("clearGattCache", e.toString());
                    }

                    Log.d("clearGattCache", "CLEAR GATT CACHE: " + hasCleared);
                    result.success(null);
                } else {
                    result.error("clearGattCache", "no instance of BluetoothGatt, have you connected first?", null);
                }

                break;
            }

            case "disconnect":
            {
                String deviceId = (String)call.arguments;
                BluetoothDeviceCache cache = mDevices.get(deviceId);
                if(cache != null) {
                    invokeMethodUIThread2("blueLog", "disconnect");
                    BluetoothGatt gattServer = cache.gatt;
                    try {
                        gattServer.disconnect();
                    } catch (Exception e) {
                        Log.w(TAG, "disconnect failed: " + e);
                    }

                    // 正常情况由 onConnectionStateChange 关闭 GATT。部分 Android 设备在异常连接后
                    // 不再回调 DISCONNECTED，因此增加延迟兜底，避免旧 GATT 污染下一次连接。
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        if (removeGattIfCurrent(deviceId, gattServer)) {
                            closeGattQuietly(gattServer);
                            isConnecting = false;
                            invokeMethodUIThread2("blueLog", "forced GATT close after disconnect timeout: " + deviceId);
                            invokeMethodUIThread("DeviceState", ProtoMaker.from(
                                    gattServer.getDevice(), BluetoothProfile.STATE_DISCONNECTED).toByteArray());
                        }
                    }, 300);
                }
                closeConnection();
                result.success(null);
                break;
            }
            case "dissPar":
            {
                String deviceId = (String)call.arguments;
                BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(deviceId);
                BluetoothDeviceCache cache = mDevices.remove(deviceId);
                try {
                    Method m = device.getClass()
                            .getMethod("removeBond", (Class[]) null);
                    m.invoke(device, (Object[]) null);
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
                if(cache != null) {
                    BluetoothGatt gattServer = cache.gatt;
                    gattServer.disconnect();
                    int state = mBluetoothManager.getConnectionState(device, BluetoothProfile.GATT);
                    if(state == BluetoothProfile.STATE_DISCONNECTED) {
                        gattServer.close();
                    }
                }
                result.success(null);
                break;
            }

            case "deviceState":
            {
                String deviceId = (String)call.arguments;
                BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(deviceId);
                int state = mBluetoothManager.getConnectionState(device, BluetoothProfile.GATT);
                if(isConnecting == true){
                    state = BluetoothProfile.STATE_CONNECTING;
                }
                log(LogLevel.INFO,"deviceState====" + state);
                try {
                    result.success(ProtoMaker.from(device, state).toByteArray());
                } catch(Exception e) {
                    result.error("device_state_error", e.getMessage(), e);
                }
                break;
            }
            case "sppDeviceState": {
                String deviceId = (String) call.arguments;
                BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(deviceId);
                int state = mBluetoothManager.getConnectionState(device, BluetoothProfile.GATT);
                if (isSPPConnect) {
                    state = BluetoothProfile.STATE_CONNECTED;
                } else {
                    state = BluetoothProfile.STATE_CONNECTING;
                }
                log(LogLevel.INFO, "deviceState====" + state);
                try {
                    result.success(ProtoMaker.from(device, state).toByteArray());
                } catch (Exception e) {
                    result.error("device_state_error", e.getMessage(), e);
                }
                break;
            }
            case "blueLog":
            {
                result.success("");
                break;
            }

            case "discoverServices":
            {
                String deviceId = (String)call.arguments;
                try {
                    BluetoothGatt gatt = locateGatt(deviceId);
                    if(gatt.discoverServices()) {
                        result.success(null);
                    } else {
                        result.error("discover_services_error", "unknown reason", null);
                    }
                } catch(Exception e) {
                    result.error("discover_services_error", e.getMessage(), e);
                }
                break;
            }

            case "services":
            {
                String deviceId = (String)call.arguments;
                try {
                    BluetoothGatt gatt = locateGatt(deviceId);
                    Protos.DiscoverServicesResult.Builder p = Protos.DiscoverServicesResult.newBuilder();
                    p.setRemoteId(deviceId);
                    for(BluetoothGattService s : gatt.getServices()){
                        p.addServices(ProtoMaker.from(gatt.getDevice(), s, gatt));
                    }
                    result.success(p.build().toByteArray());
                } catch(Exception e) {
                    result.error("get_services_error", e.getMessage(), e);
                }
                break;
            }

            case "readCharacteristic":
            {
                byte[] data = call.arguments();
                Protos.ReadCharacteristicRequest request;
                try {
                    request = Protos.ReadCharacteristicRequest.newBuilder().mergeFrom(data).build();
                } catch (InvalidProtocolBufferException e) {
                    result.error("RuntimeException", e.getMessage(), e);
                    break;
                }

                BluetoothGatt gattServer;
                BluetoothGattCharacteristic characteristic;
                try {
                    gattServer = locateGatt(request.getRemoteId());
                    characteristic = locateCharacteristic(gattServer, request.getServiceUuid(), request.getSecondaryServiceUuid(), request.getCharacteristicUuid());
                } catch(Exception e) {
                    result.error("read_characteristic_error", e.getMessage(), null);
                    return;
                }

                if(gattServer.readCharacteristic(characteristic)) {
                    result.success(null);
                } else {
                    result.error("read_characteristic_error", "unknown reason, may occur if readCharacteristic was called before last read finished.", null);
                }
                break;
            }

            case "readDescriptor":
            {
                byte[] data = call.arguments();
                Protos.ReadDescriptorRequest request;
                try {
                    request = Protos.ReadDescriptorRequest.newBuilder().mergeFrom(data).build();
                } catch (InvalidProtocolBufferException e) {
                    result.error("RuntimeException", e.getMessage(), e);
                    break;
                }

                BluetoothGatt gattServer;
                BluetoothGattCharacteristic characteristic;
                BluetoothGattDescriptor descriptor;
                try {
                    gattServer = locateGatt(request.getRemoteId());
                    characteristic = locateCharacteristic(gattServer, request.getServiceUuid(), request.getSecondaryServiceUuid(), request.getCharacteristicUuid());
                    descriptor = locateDescriptor(characteristic, request.getDescriptorUuid());
                } catch(Exception e) {
                    result.error("read_descriptor_error", e.getMessage(), null);
                    return;
                }

                if(gattServer.readDescriptor(descriptor)) {
                    result.success(null);
                } else {
                    result.error("read_descriptor_error", "unknown reason, may occur if readDescriptor was called before last read finished.", null);
                }
                break;
            }

            case "SPPWriteCharacteristic": {
                byte[] data = call.arguments();
                if (outputStream != null) {
                    try {
                        outputStream.write(data);
                        Log.d("111", "spp 写入成功");
                    } catch (IOException e) {
                        Log.d("111", "spp 写入失败");
                        result.error("write_characteristic_error", "writeCharacteristic failed", null);
                        return;
                    }
                }
                result.success(null);
                break;
            }

            case "writeCharacteristic":
            {
                byte[] data = call.arguments();
                Protos.WriteCharacteristicRequest request;
                try {
                    request = Protos.WriteCharacteristicRequest.newBuilder().mergeFrom(data).build();
                } catch (InvalidProtocolBufferException e) {
                    result.error("RuntimeException", e.getMessage(), e);
                    break;
                }

                BluetoothGatt gattServer;
                BluetoothGattCharacteristic characteristic;
                try {
                    gattServer = locateGatt(request.getRemoteId());
                    characteristic = locateCharacteristic(gattServer, request.getServiceUuid(), request.getSecondaryServiceUuid(), request.getCharacteristicUuid());
                } catch(Exception e) {
                    result.error("write_characteristic_error", e.getMessage(), null);
                    return;
                }

                // Set characteristic to new value
                if(!characteristic.setValue(request.getValue().toByteArray())){
                    result.error("write_characteristic_error", "could not set the local value of characteristic", null);
                }

                // Apply the correct write type
                if(request.getWriteType() == Protos.WriteCharacteristicRequest.WriteType.WITHOUT_RESPONSE) {
                    characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                } else {
                    characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                }

                if(!gattServer.writeCharacteristic(characteristic)){
                    result.error("write_characteristic_error", "writeCharacteristic failed", null);
                    return;
                }

                result.success(null);
                break;
            }

            case "writeDescriptor":
            {
                byte[] data = call.arguments();
                Protos.WriteDescriptorRequest request;
                try {
                    request = Protos.WriteDescriptorRequest.newBuilder().mergeFrom(data).build();
                } catch (InvalidProtocolBufferException e) {
                    result.error("RuntimeException", e.getMessage(), e);
                    break;
                }

                BluetoothGatt gattServer;
                BluetoothGattCharacteristic characteristic;
                BluetoothGattDescriptor descriptor;
                try {
                    gattServer = locateGatt(request.getRemoteId());
                    characteristic = locateCharacteristic(gattServer, request.getServiceUuid(), request.getSecondaryServiceUuid(), request.getCharacteristicUuid());
                    descriptor = locateDescriptor(characteristic, request.getDescriptorUuid());
                } catch(Exception e) {
                    result.error("write_descriptor_error", e.getMessage(), null);
                    return;
                }

                // Set descriptor to new value
                if(!descriptor.setValue(request.getValue().toByteArray())){
                    result.error("write_descriptor_error", "could not set the local value for descriptor", null);
                }

                if(!gattServer.writeDescriptor(descriptor)){
                    result.error("write_descriptor_error", "writeCharacteristic failed", null);
                    return;
                }

                result.success(null);
                break;
            }

            case "setNotification":
            {
                byte[] data = call.arguments();
                Protos.SetNotificationRequest request;
                try {
                    request = Protos.SetNotificationRequest.newBuilder().mergeFrom(data).build();
                } catch (InvalidProtocolBufferException e) {
                    result.error("RuntimeException", e.getMessage(), e);
                    break;
                }

                BluetoothGatt gattServer;
                BluetoothGattCharacteristic characteristic;
                BluetoothGattDescriptor cccDescriptor;
                try {
                    gattServer = locateGatt(request.getRemoteId());
                    characteristic = locateCharacteristic(gattServer, request.getServiceUuid(), request.getSecondaryServiceUuid(), request.getCharacteristicUuid());
                    cccDescriptor = characteristic.getDescriptor(CCCD_ID);
                    if(cccDescriptor == null) {
                        //Some devices - including the widely used Bluno do not actually set the CCCD_ID.
                        //thus setNotifications works perfectly (tested on Bluno) without cccDescriptor
                        log(LogLevel.INFO, "could not locate CCCD descriptor for characteristic: " + characteristic.getUuid().toString());
                    }
                } catch(Exception e) {
                    result.error("set_notification_error", e.getMessage(), null);
                    return;
                }

                byte[] value = null;

                if(request.getEnable()) {
                    boolean canNotify = (characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0;
                    boolean canIndicate = (characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_INDICATE) > 0;
                    if(!canIndicate && !canNotify) {
                        result.error("set_notification_error", "the characteristic cannot notify or indicate", null);
                        return;
                    }
                    if(canIndicate) {
                        value = BluetoothGattDescriptor.ENABLE_INDICATION_VALUE;
                    }
                    if(canNotify) {
                        value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
                    }
                } else {
                    value = BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE;
                }

                if(!gattServer.setCharacteristicNotification(characteristic, request.getEnable())){
                    result.error("set_notification_error", "could not set characteristic notifications to :" + request.getEnable(), null);
                    return;
                }

                if(cccDescriptor != null) {
                    if (!cccDescriptor.setValue(value)) {
                        result.error("set_notification_error", "error when setting the descriptor value to: " + Arrays.toString(value), null);
                        return;
                    }

                    if (!gattServer.writeDescriptor(cccDescriptor)) {
                        result.error("set_notification_error", "error when writing the descriptor", null);
                        return;
                    }
                }

                result.success(null);
                break;
            }

            case "mtu":
            {
                String deviceId = (String)call.arguments;
                BluetoothDeviceCache cache = mDevices.get(deviceId);
                if(cache != null) {
                    Protos.MtuSizeResponse.Builder p = Protos.MtuSizeResponse.newBuilder();
                    p.setRemoteId(deviceId);
                    p.setMtu(cache.mtu);
                    result.success(p.build().toByteArray());
                } else {
                    result.error("mtu", "no instance of BluetoothGatt, have you connected first?", null);
                }
                break;
            }

            case "requestMtu":
            {
                byte[] data = call.arguments();
                Protos.MtuSizeRequest request;
                try {
                    request = Protos.MtuSizeRequest.newBuilder().mergeFrom(data).build();
                } catch (InvalidProtocolBufferException e) {
                    result.error("RuntimeException", e.getMessage(), e);
                    break;
                }

                BluetoothGatt gatt;
                try {
                    gatt = locateGatt(request.getRemoteId());
                    int mtu = request.getMtu();
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        if(gatt.requestMtu(mtu)) {
                            result.success(null);
                        } else {
                            result.error("requestMtu", "gatt.requestMtu returned false", null);
                        }
                    } else {
                        result.error("requestMtu", "Only supported on devices >= API 21 (Lollipop). This device == " + Build.VERSION.SDK_INT, null);
                    }
                } catch(Exception e) {
                    result.error("requestMtu", e.getMessage(), e);
                }

                break;
            }

            case "readRssi":
            {
                String remoteId = (String)call.arguments;
                BluetoothGatt gatt;
                try {
                    gatt = locateGatt(remoteId);
                    if(gatt.readRemoteRssi()) {
                        result.success(null);
                    } else {
                        result.error("readRssi", "gatt.readRemoteRssi returned false", null);
                    }
                } catch(Exception e) {
                    result.error("readRssi", e.getMessage(), e);
                }

                break;
            }

            case "createSocket":
            {
                String deviceId = (String)call.arguments;
                BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(deviceId);
                Log.d(TAG, "createSocket" + device.getBondState());
                if(device.getBondState() != BluetoothDevice.BOND_BONDED){
                    try {
                        Method createBondMethod = BluetoothDevice.class.getMethod("createBond",int.class);
                        Boolean returnValue = (Boolean) createBondMethod.invoke(device,BluetoothDevice.TRANSPORT_BREDR);
                        Log.d(TAG, "配对成功 " + returnValue);
//            if (returnValue){
//              Log.d(TAG, "配对成功...");
//
////             if (getDeviceBrand().contains("vivo")){
////               BluetoothSocket socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
////               socket.connect();
//////               Log.d(TAG, "vivo 手机取消配对");
//////               BluetoothDeviceCache cache = mDevices.remove(deviceId);
//////               try {
//////                 Method m = device.getClass()
//////                         .getMethod("removeBond", (Class[]) null);
//////                 m.invoke(device, (Object[]) null);
//////               } catch (Exception e) {
//////                 Log.e(TAG, e.getMessage());
//////               }
//////               if(cache != null) {
//////                 BluetoothGatt gattServer = cache.gatt;
//////                 gattServer.disconnect();
//////                 int state = mBluetoothManager.getConnectionState(device, BluetoothProfile.GATT);
//////                 if(state == BluetoothProfile.STATE_DISCONNECTED) {
//////                   gattServer.close();
//////                 }
//////               }
////             }
//
//            }
                    } catch (Exception e) {
                        result.error("createSocket", e.getMessage(), e);
                        return;
                    }
                }


//        try {
//          mSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);
//        } catch (Exception e) {
//          result.error("createSocket", e.getMessage(), e);
//          return;
//        }
//        try {
//          mSocket.connect();
//          result.success(null);
//        } catch (Exception e) {
//          result.error("createSocke connect failed", e.getMessage(), e);
//          try {
//            mSocket.close();
//            mSocket = null;
//          } catch (Exception e2) {
//            result.error("createSocke connect failed", e2.getMessage(), e2);
//          }
//          return;
//        }
                break;
            }

            case "dataSPP": {
                result.success(null);
                break;
            }

            default:
            {
                result.notImplemented();
                break;
            }
        }
    }

    public static String getDeviceBrand() {
        return Build.BRAND;
    }

    private void ensurePermissionBeforeAction(String permission, OperationOnPermission operation) {
        if (permission != null &&
                ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
            operationsOnPermission.put(lastEventId, (granted, perm) -> {
                operationsOnPermission.remove(lastEventId);
                operation.op(granted, perm);
            });
            ActivityCompat.requestPermissions(
                    activityBinding.getActivity(),
                    new String[]{permission},
                    lastEventId);
            lastEventId++;
        } else {
            operation.op(true, permission);
        }
    }

    private BluetoothGatt locateGatt(String remoteId) throws Exception {
        BluetoothDeviceCache cache = mDevices.get(remoteId);
        if(cache == null || cache.gatt == null) {
            invokeMethodUIThread2("blueLog", "no instance of BluetoothGatt, have you connected first?: " + ((cache == null) ? "cache false" : "cache true") + ((cache.gatt == null) ? "cache.gatt false" : "cache.gatt true"));
            throw new Exception("no instance of BluetoothGatt, have you connected first?");
        } else {
            return cache.gatt;
        }
    }

    private BluetoothGattCharacteristic locateCharacteristic(BluetoothGatt gattServer, String serviceId, String secondaryServiceId, String characteristicId) throws Exception {
        BluetoothGattService primaryService = gattServer.getService(UUID.fromString(serviceId));
        if(primaryService == null) {
            throw new Exception("service (" + serviceId + ") could not be located on the device");
        }
        BluetoothGattService secondaryService = null;
        if(secondaryServiceId.length() > 0) {
            for(BluetoothGattService s : primaryService.getIncludedServices()){
                if(s.getUuid().equals(UUID.fromString(secondaryServiceId))){
                    secondaryService = s;
                }
            }
            if(secondaryService == null) {
                throw new Exception("secondary service (" + secondaryServiceId + ") could not be located on the device");
            }
        }
        BluetoothGattService service = (secondaryService != null) ? secondaryService : primaryService;
        BluetoothGattCharacteristic characteristic = service.getCharacteristic(UUID.fromString(characteristicId));
        if(characteristic == null) {
            throw new Exception("characteristic (" + characteristicId + ") could not be located in the service ("+service.getUuid().toString()+")");
        }
        return characteristic;
    }

    private BluetoothGattDescriptor locateDescriptor(BluetoothGattCharacteristic characteristic, String descriptorId) throws Exception {
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(UUID.fromString(descriptorId));
        if(descriptor == null) {
            throw new Exception("descriptor (" + descriptorId + ") could not be located in the characteristic ("+characteristic.getUuid().toString()+")");
        }
        return descriptor;
    }

    private void startBluetoothDiscovery(DeviceBack callback) {
        if (mBluetoothAdapter.isEnabled()) {
            // 开始经典蓝牙设备扫描
            Log.i(TAG,"开始经典蓝牙扫描");
            baseDevice = callback;
            mBluetoothAdapter.startDiscovery();
        }
    }

    private final BroadcastReceiver classicReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // 发现新的经典蓝牙设备
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                String deviceName = device.getName();
                String deviceAddress = device.getAddress();
                String deviceInfo = deviceName + "\n" + deviceAddress;
                Log.i(TAG,"经典蓝牙设备：" + deviceInfo);
                baseDevice.onDeviceBack(device);
            }
        }
    };

    private final StreamHandler stateHandler = new StreamHandler() {
        private EventSink sink;

        private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                final String action = intent.getAction();

                if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) {
                    final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                            BluetoothAdapter.ERROR);
                    switch (state) {
                        case BluetoothAdapter.STATE_OFF:
                            closeConnection();
                            sink.success(Protos.BluetoothState.newBuilder().setState(Protos.BluetoothState.State.OFF).build().toByteArray());
                            break;
                        case BluetoothAdapter.STATE_TURNING_OFF:
                            sink.success(Protos.BluetoothState.newBuilder().setState(Protos.BluetoothState.State.TURNING_OFF).build().toByteArray());
                            break;
                        case BluetoothAdapter.STATE_ON:
                            sink.success(Protos.BluetoothState.newBuilder().setState(Protos.BluetoothState.State.ON).build().toByteArray());
                            break;
                        case BluetoothAdapter.STATE_TURNING_ON:
                            sink.success(Protos.BluetoothState.newBuilder().setState(Protos.BluetoothState.State.TURNING_ON).build().toByteArray());
                            break;
                    }
                }  else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)) {
                    BluetoothDevice btDevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    int state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1);
                    if (state == BluetoothDevice.BOND_NONE) {
                        invokeMethodUIThread2("blueLog", "已取消与设备" + btDevice.getName() + "的配对");
                        Log.i(TAG,"已取消与设备" + btDevice.getName() + "的配对");
                    } else if (state == BluetoothDevice.BOND_BONDED) {
                        invokeMethodUIThread2("blueLog", "与设备" + btDevice.getName() + "配对成功");
                        Log.i(TAG,"与设备" + btDevice.getName() + "配对成功");
                    }
                }
            }
        };

        @Override
        public void onListen(Object o, EventChannel.EventSink eventSink) {
            sink = eventSink;
            IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
            filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);//设备的绑定状态
            context.registerReceiver(mReceiver, filter);
        }

        @Override
        public void onCancel(Object o) {
            sink = null;
            context.unregisterReceiver(mReceiver);
        }
    };

    private void startScan(MethodCall call, Result result) {
        Log.i(TAG,"原生开始扫描");
        byte[] data = call.arguments();
        Protos.ScanSettings settings;

        try {
            settings = Protos.ScanSettings.newBuilder().mergeFrom(data).build();
            allowDuplicates = settings.getAllowDuplicates();
            macDeviceScanned.clear();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                startScan21(settings);
            } else {
                startScan18(settings);
            }
            result.success(null);
        } catch (Exception e) {
            result.error("startScan", e.getMessage(), e);
        }
    }

    private void stopScan() {
        Log.i(TAG,"原生停止扫描");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            stopScan21();
        } else {
            stopScan18();
        }
    }

    private ScanCallback scanCallback21;

    @TargetApi(21)
    private ScanCallback getScanCallback21() {
        if(scanCallback21 == null){
            scanCallback21 = new ScanCallback() {

                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    super.onScanResult(callbackType, result);
                    if(result != null){
                        if (!allowDuplicates && result.getDevice() != null && result.getDevice().getAddress() != null) {
                            if (macDeviceScanned.contains(result.getDevice().getAddress())) {
                                return;
                            }
                            macDeviceScanned.add(result.getDevice().getAddress());
                        }
                        Protos.ScanResult scanResult = ProtoMaker.from(result.getDevice(), result);
                        invokeMethodUIThread("ScanResult", scanResult.toByteArray());
                    }
                }

                @Override
                public void onBatchScanResults(List<ScanResult> results) {
                    super.onBatchScanResults(results);

                }

                @Override
                public void onScanFailed(int errorCode) {
                    super.onScanFailed(errorCode);
                    Log.e(TAG, "BLE scan failed, errorCode=" + errorCode);
                    invokeMethodUIThread2("blueLog", "[onScanFailed] errorCode=" + errorCode);
                }
            };
        }
        return scanCallback21;
    }

    @TargetApi(21)
    private void startScan21(Protos.ScanSettings proto) throws IllegalStateException {
        BluetoothLeScanner scanner = mBluetoothAdapter.getBluetoothLeScanner();
        if(scanner == null) throw new IllegalStateException("getBluetoothLeScanner() is null. Is the Adapter on?");
        int scanMode = proto.getAndroidScanMode();
        List<ScanFilter> filters = fetchFilters(proto);

        try {
            scanner.stopScan(getScanCallback21());
        } catch (Exception e) {
            Log.w(TAG, "stop previous scan before restart failed: " + e.getMessage());
        }

        ScanSettings.Builder builder = new ScanSettings.Builder()
                .setScanMode(scanMode);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Keep legacy scan mode for broader compatibility with wearable devices
            // that only advertise in the classic BLE legacy format.
            builder.setLegacy(true);
        }

        ScanSettings settings = builder.build();
        scanner.startScan(filters, settings, getScanCallback21());
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private List<ScanFilter> fetchFilters(Protos.ScanSettings proto) {
        int macCount = proto.getMacAddressesCount();
        int serviceCount = proto.getServiceUuidsCount();
        List<ScanFilter> filters = new ArrayList<>(macCount + serviceCount);

        for (int i = 0; i < macCount; i++) {
            String macAddress = proto.getMacAddresses(i);
            ScanFilter filter = new ScanFilter.Builder()
                    .setDeviceAddress(macAddress)
                    .build();
            filters.add(filter);
        }

        for (int i = 0; i < serviceCount; i++) {
            String uuid = proto.getServiceUuids(i);
            ScanFilter filter = new ScanFilter.Builder()
                    .setServiceUuid(ParcelUuid.fromString(uuid))
                    .build();
            filters.add(filter);
        }

        return filters;
    }

    @TargetApi(21)
    private void stopScan21() {
        BluetoothLeScanner scanner = mBluetoothAdapter.getBluetoothLeScanner();
        if(scanner != null) scanner.stopScan(getScanCallback21());
    }

    private BluetoothAdapter.LeScanCallback scanCallback18;

    private BluetoothAdapter.LeScanCallback getScanCallback18() {
        if(scanCallback18 == null) {
            scanCallback18 = (bluetoothDevice, rssi, scanRecord) -> {
                if (!allowDuplicates && bluetoothDevice != null && bluetoothDevice.getAddress() != null) {
                    if (macDeviceScanned.contains(bluetoothDevice.getAddress())) return;
                    macDeviceScanned.add(bluetoothDevice.getAddress());
                }

                Protos.ScanResult scanResult = ProtoMaker.from(bluetoothDevice, scanRecord, rssi);
                invokeMethodUIThread("ScanResult", scanResult.toByteArray());
            };
        }
        return scanCallback18;
    }

    @SuppressWarnings("deprecation")
    private void startScan18(Protos.ScanSettings proto) throws IllegalStateException {
        List<String> serviceUuids = proto.getServiceUuidsList();
        UUID[] uuids = new UUID[serviceUuids.size()];
        for(int i = 0; i < serviceUuids.size(); i++) {
            uuids[i] = UUID.fromString(serviceUuids.get(i));
        }
        boolean success = mBluetoothAdapter.startLeScan(uuids, getScanCallback18());
        if(!success) throw new IllegalStateException("getBluetoothLeScanner() is null. Is the Adapter on?");
    }

    @SuppressWarnings("deprecation")
    private void stopScan18() {
        mBluetoothAdapter.stopLeScan(getScanCallback18());
    }

    /**
     * 仅当 Map 中仍然保存的是指定 GATT 时才移除。
     *
     * 断线后立即重连时，旧 GATT 的回调可能在新 GATT 建立后才到达。直接按地址
     * remove 会误删新连接，使后续服务发现、读写和再次连接都找不到有效实例。
     */
    private boolean removeGattIfCurrent(String deviceId, BluetoothGatt gatt) {
        synchronized (mDevices) {
            BluetoothDeviceCache cache = mDevices.get(deviceId);
            if (cache == null || cache.gatt != gatt) {
                return false;
            }
            mDevices.remove(deviceId);
            return true;
        }
    }

    /** 关闭指定 GATT；重复 close 在这里按幂等清理处理。 */
    private void closeGattQuietly(BluetoothGatt gatt) {
        try {
            gatt.close();
        } catch (Exception e) {
            Log.w(TAG, "close GATT failed: " + e);
        }
    }

    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            log(LogLevel.DEBUG, "[onConnectionStateChange] status: " + status + " newState: " + newState);
            String address = gatt.getDevice().getAddress();
            BluetoothDeviceCache currentCache = mDevices.get(address);
            boolean isCurrentGatt = currentCache != null && currentCache.gatt == gatt;

            if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                closeGattQuietly(gatt);
                if (isCurrentGatt) {
                    removeGattIfCurrent(address, gatt);
                    closeConnection();
                }
            }

            // 旧 GATT 的回调可能晚于新连接到达。它只能释放自己，不能删除新 GATT、
            // 复位新连接状态或向 Dart 发送一个会使新连接失败的迟到事件。
            if (!isCurrentGatt) {
                log(LogLevel.WARNING, "ignore stale GATT callback for " + address
                        + " status: " + status + " newState: " + newState);
                return;
            }

            isConnecting = false;
            log(LogLevel.INFO,"onConnectionStateChange====" + "isConnecting:" + isConnecting);
            invokeMethodUIThread2("blueLog", "[onConnectionStateChange] status: " + status + " newState: " + newState + " device: " + address);

            invokeMethodUIThread("DeviceState", ProtoMaker.from(gatt.getDevice(), newState).toByteArray());
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            log(LogLevel.DEBUG, "[onServicesDiscovered] count: " + gatt.getServices().size() + " status: " + status);
            Protos.DiscoverServicesResult.Builder p = Protos.DiscoverServicesResult.newBuilder();
            p.setRemoteId(gatt.getDevice().getAddress());
            for(BluetoothGattService s : gatt.getServices()) {
                p.addServices(ProtoMaker.from(gatt.getDevice(), s, gatt));
            }
            invokeMethodUIThread("DiscoverServicesResult", p.build().toByteArray());
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            log(LogLevel.DEBUG, "[onCharacteristicRead] uuid: " + characteristic.getUuid().toString() + " status: " + status);
            Protos.ReadCharacteristicResponse.Builder p = Protos.ReadCharacteristicResponse.newBuilder();
            p.setRemoteId(gatt.getDevice().getAddress());
            p.setCharacteristic(ProtoMaker.from(gatt.getDevice(), characteristic, gatt));


            invokeMethodUIThread("ReadCharacteristicResponse", p.build().toByteArray());
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
//      log(LogLevel.DEBUG, "[onCharacteristicWrite] uuid: " + characteristic.getUuid().toString() + " status: " + status);
            Protos.WriteCharacteristicRequest.Builder request = Protos.WriteCharacteristicRequest.newBuilder();
            request.setRemoteId(gatt.getDevice().getAddress());
            request.setCharacteristicUuid(characteristic.getUuid().toString());
            request.setServiceUuid(characteristic.getService().getUuid().toString());
            Protos.WriteCharacteristicResponse.Builder p = Protos.WriteCharacteristicResponse.newBuilder();
            p.setRequest(request);
            p.setSuccess(status == BluetoothGatt.GATT_SUCCESS);
            invokeMethodUIThread("WriteCharacteristicResponse", p.build().toByteArray());
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
//      log(LogLevel.DEBUG, "[onCharacteristicChanged] uuid: " + characteristic.getUuid().toString());
            Protos.OnCharacteristicChanged.Builder p = Protos.OnCharacteristicChanged.newBuilder();
            p.setRemoteId(gatt.getDevice().getAddress());
            p.setCharacteristic(ProtoMaker.from(gatt.getDevice(), characteristic, gatt));
//      byte[] byteArray = p.build().toByteArray();
//      int[] intArray = new int[byteArray.length];
//      for (int i = 0; i < byteArray.length; i++) {
//        // 将每个字节转换为无符号整数
//        intArray[i] = byteArray[i] & 0xFF;
//      }
//      if(intArray.length > 263){
//        int[] subArray =  Arrays.copyOfRange(intArray, 263, intArray.length);
//        invokeMethodUIThread2("blueLog", "读取的数据" + Arrays.toString(subArray));
//      }
            invokeMethodUIThread("OnCharacteristicChanged", p.build().toByteArray());
        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            log(LogLevel.DEBUG, "[onDescriptorRead] uuid: " + descriptor.getUuid().toString() + " status: " + status);
            // Rebuild the ReadAttributeRequest and send back along with response
            Protos.ReadDescriptorRequest.Builder q = Protos.ReadDescriptorRequest.newBuilder();
            q.setRemoteId(gatt.getDevice().getAddress());
            q.setCharacteristicUuid(descriptor.getCharacteristic().getUuid().toString());
            q.setDescriptorUuid(descriptor.getUuid().toString());
            if(descriptor.getCharacteristic().getService().getType() == BluetoothGattService.SERVICE_TYPE_PRIMARY) {
                q.setServiceUuid(descriptor.getCharacteristic().getService().getUuid().toString());
            } else {
                // Reverse search to find service
                for(BluetoothGattService s : gatt.getServices()) {
                    for(BluetoothGattService ss : s.getIncludedServices()) {
                        if(ss.getUuid().equals(descriptor.getCharacteristic().getService().getUuid())){
                            q.setServiceUuid(s.getUuid().toString());
                            q.setSecondaryServiceUuid(ss.getUuid().toString());
                            break;
                        }
                    }
                }
            }
            Protos.ReadDescriptorResponse.Builder p = Protos.ReadDescriptorResponse.newBuilder();
            p.setRequest(q);
            p.setValue(ByteString.copyFrom(descriptor.getValue()));
            invokeMethodUIThread("ReadDescriptorResponse", p.build().toByteArray());
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            log(LogLevel.DEBUG, "[onDescriptorWrite] uuid: " + descriptor.getUuid().toString() + " status: " + status);
            Protos.WriteDescriptorRequest.Builder request = Protos.WriteDescriptorRequest.newBuilder();
            request.setRemoteId(gatt.getDevice().getAddress());
            request.setDescriptorUuid(descriptor.getUuid().toString());
            request.setCharacteristicUuid(descriptor.getCharacteristic().getUuid().toString());
            request.setServiceUuid(descriptor.getCharacteristic().getService().getUuid().toString());
            Protos.WriteDescriptorResponse.Builder p = Protos.WriteDescriptorResponse.newBuilder();
            p.setRequest(request);
            p.setSuccess(status == BluetoothGatt.GATT_SUCCESS);
            invokeMethodUIThread("WriteDescriptorResponse", p.build().toByteArray());

            if(descriptor.getUuid().compareTo(CCCD_ID) == 0) {
                // SetNotificationResponse
                Protos.SetNotificationResponse.Builder q = Protos.SetNotificationResponse.newBuilder();
                q.setRemoteId(gatt.getDevice().getAddress());
                q.setCharacteristic(ProtoMaker.from(gatt.getDevice(), descriptor.getCharacteristic(), gatt));
                invokeMethodUIThread("SetNotificationResponse", q.build().toByteArray());
            }
        }

        @Override
        public void onReliableWriteCompleted(BluetoothGatt gatt, int status) {
            log(LogLevel.DEBUG, "[onReliableWriteCompleted] status: " + status);
        }

        @Override
        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
            log(LogLevel.DEBUG, "[onReadRemoteRssi] rssi: " + rssi + " status: " + status);
            if(status == BluetoothGatt.GATT_SUCCESS) {
                Protos.ReadRssiResult.Builder p = Protos.ReadRssiResult.newBuilder();
                p.setRemoteId(gatt.getDevice().getAddress());
                p.setRssi(rssi);
                invokeMethodUIThread("ReadRssiResult", p.build().toByteArray());
            }
        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            log(LogLevel.DEBUG, "[onMtuChanged] mtu: " + mtu + " status: " + status);
            if(status == BluetoothGatt.GATT_SUCCESS) {
                if(mDevices.containsKey(gatt.getDevice().getAddress())) {
                    BluetoothDeviceCache cache = mDevices.get(gatt.getDevice().getAddress());
                    if (cache != null) {
                        cache.mtu = mtu;
                    }
                    Protos.MtuSizeResponse.Builder p = Protos.MtuSizeResponse.newBuilder();
                    p.setRemoteId(gatt.getDevice().getAddress());
                    p.setMtu(mtu);
                    invokeMethodUIThread("MtuSize", p.build().toByteArray());
                }
            }
        }
    };

    private void log(LogLevel level, String message) {
        Log.d(TAG, message);
    }

    private void  invokeMethodUIThread(final String name, final byte[] byteArray)
    {
        new Handler(Looper.getMainLooper()).post(() -> {
            synchronized (tearDownLock) {
                //Could already be teared down at this moment
                if (channel != null) {
                    channel.invokeMethod(name, byteArray);
                } else {
                    Log.w(TAG, "Tried to call " + name + " on closed channel");
                }
            }
        });
    }

    private void  invokeMethodUIThread2(final String name, final String text)
    {
        new Handler(Looper.getMainLooper()).post(() -> {
            synchronized (tearDownLock) {
                //Could already be teared down at this moment
                if (channel != null) {
                    channel.invokeMethod(name, text);
                } else {
                    Log.w(TAG, "Tried to call " + name + " on closed channel");
                }
            }
        });
    }

    enum LogLevel
    {
        EMERGENCY, ALERT, CRITICAL, ERROR, WARNING, NOTICE, INFO, DEBUG
    }

    // BluetoothDeviceCache contains any other cached information not stored in Android Bluetooth API
    // but still needed Dart side.
    static class BluetoothDeviceCache {
        final BluetoothGatt gatt;
        int mtu;

        BluetoothDeviceCache(BluetoothGatt gatt) {
            this.gatt = gatt;
            mtu = 20;
        }
    }
}
