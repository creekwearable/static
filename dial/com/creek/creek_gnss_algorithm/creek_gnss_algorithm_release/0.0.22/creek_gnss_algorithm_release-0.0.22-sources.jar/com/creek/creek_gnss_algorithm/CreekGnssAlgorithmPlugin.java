package com.creek.creek_gnss_algorithm;

import androidx.annotation.NonNull;

import com.creek.creekgnssalgorithm.CreekGnssAlgorithm;
import com.creek.creekgnssalgorithm.GnssLocation;
import com.creek.creekgnssalgorithm.GnssResult;
import com.creek.creekgnssalgorithm.GnssVersion;

import java.util.HashMap;
import java.util.Map;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;

/** CreekGnssAlgorithmPlugin */
public class CreekGnssAlgorithmPlugin implements FlutterPlugin, MethodCallHandler {
  private MethodChannel channel;
  private final CreekGnssAlgorithm algorithm = new CreekGnssAlgorithm();

  @Override
  public void onAttachedToEngine(@NonNull FlutterPluginBinding flutterPluginBinding) {
    channel = new MethodChannel(flutterPluginBinding.getBinaryMessenger(), "creek_gnss_algorithm");
    channel.setMethodCallHandler(this);
  }

  @Override
  public void onMethodCall(@NonNull MethodCall call, @NonNull Result result) {
    switch (call.method) {
      case "init":
        Number haccLimit = call.argument("haccLimit");
        algorithm.init(haccLimit == null ? 10.0f : haccLimit.floatValue());
        result.success(null);
        break;
      case "getVersion":
        result.success(toVersionMap(algorithm.getVersion()));
        break;
      case "process":
        Map<?, ?> arguments = call.arguments();
        if (arguments == null || !(arguments.get("location") instanceof Map)) {
          result.error("invalid_arguments", "location is required", null);
          return;
        }
        Map<?, ?> locationMap = (Map<?, ?>) arguments.get("location");
        int sportType = toInt(arguments.get("sportType"));
        GnssResult gnssResult = algorithm.process(toLocation(locationMap), sportType);
        result.success(toResultMap(gnssResult));
        break;
      default:
        result.notImplemented();
        break;
    }
  }

  @Override
  public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) {
    channel.setMethodCallHandler(null);
  }

  private GnssLocation toLocation(Map<?, ?> map) {
    return new GnssLocation(
        toInt(map.get("utcTime")),
        toInt(map.get("rmcLocationStatus")),
        toInt(map.get("rmcLatitude")),
        toInt(map.get("rmcLongitude")),
        toInt(map.get("rmcNorthOrSouth")),
        toInt(map.get("rmcEastOrWest")),
        toFloat(map.get("gsaPdop")),
        toFloat(map.get("hacc")),
        toFloat(map.get("rmcSpeed")),
        toFloat(map.get("rmcCog"))
    );
  }

  private Map<String, Object> toVersionMap(GnssVersion version) {
    Map<String, Object> map = new HashMap<>();
    map.put("mainVersion", version.mainVersion);
    map.put("subVersion", version.subVersion);
    return map;
  }

  private Map<String, Object> toResultMap(GnssResult result) {
    Map<String, Object> map = new HashMap<>();
    map.put("latitude", result.latitude);
    map.put("longitude", result.longitude);
    map.put("distanceCm", result.distanceCm);
    map.put("speedKmh", result.speedKmh);
    map.put("speedPerKm", result.speedPerKm);
    map.put("gnssEnable", result.gnssEnable);
    map.put("saveFlag", result.saveFlag);
    map.put("remainTime", result.remainTime);
    map.put("locationRssi", result.locationRssi);
    return map;
  }

  private int toInt(Object value) {
    if (value instanceof Number) {
      return ((Number) value).intValue();
    }
    if (value instanceof String) {
      try {
        return Integer.parseInt((String) value);
      } catch (NumberFormatException ignored) {
        return 0;
      }
    }
    return 0;
  }

  private float toFloat(Object value) {
    if (value instanceof Number) {
      return ((Number) value).floatValue();
    }
    if (value instanceof String) {
      try {
        return Float.parseFloat((String) value);
      } catch (NumberFormatException ignored) {
        return 0.0f;
      }
    }
    return 0.0f;
  }
}
